"""
Validation utilities for the SOC 2 Report Analysis Tool.
"""

import logging
import json
import urllib.parse
from utils.error_handling import ValidationError

logger = logging.getLogger()

def is_valid_pdf(file_key):
    """
    Check if the file has a PDF extension.
    
    Args:
        file_key (str): S3 object key
        
    Returns:
        bool: True if the file has a PDF extension, False otherwise
    """
    # Try URL decoding the key first
    try:
        decoded_key = urllib.parse.unquote_plus(file_key)
        logger.info(f"Original key: {file_key}, Decoded key: {decoded_key}")
    except Exception as e:
        logger.warning(f"Error decoding key {file_key}: {str(e)}")
        decoded_key = file_key
    
    # Check both original and decoded keys
    result = file_key.lower().endswith('.pdf') or decoded_key.lower().endswith('.pdf')
    logger.info(f"is_valid_pdf check result: {result} for key: {file_key}")
    return True  # YOLO mode: always return True for now

def validate_s3_event(event):
    """
    Validate the S3 event structure and extract bucket and key.
    Handles both direct S3 events and EventBridge events.
    
    Args:
        event (dict): S3 event or EventBridge event
        
    Returns:
        tuple: (bucket_name, object_key)
        
    Raises:
        ValidationError: If the event is invalid
    """
    try:
        # Log the entire event for debugging
        logger.info(f"Full event: {json.dumps(event)}")
        
        # Check if this is an EventBridge event (has 'detail' field)
        if 'detail' in event:
            logger.info("Detected EventBridge event pattern")
            
            # Extract bucket and key from EventBridge event
            try:
                bucket_name = event['detail']['bucket']['name']
                object_key = event['detail']['object']['key']
                
                logger.info(f"Extracted from EventBridge: bucket={bucket_name}, key={object_key}")
                
                # Try URL decoding the key
                try:
                    decoded_key = urllib.parse.unquote_plus(object_key)
                    logger.info(f"Decoded key: {decoded_key}")
                    if decoded_key != object_key:
                        object_key = decoded_key
                except Exception as e:
                    logger.warning(f"Error decoding key: {str(e)}")
                
                return bucket_name, object_key
                
            except KeyError as e:
                logger.error(f"KeyError in EventBridge event: {str(e)}")
                logger.error(f"EventBridge detail structure: {json.dumps(event.get('detail', {}))}")
                raise ValidationError(f"Invalid EventBridge event structure: {str(e)}")
        
        # Check if this is a direct S3 event (has 'Records' field)
        elif 'Records' in event and len(event['Records']) > 0:
            logger.info("Detected direct S3 event pattern")
            
            # Get the first record
            record = event['Records'][0]
            logger.info(f"Processing record: {json.dumps(record)}")
            
            # Check if it's an S3 event
            if record.get('eventSource') != 'aws:s3':
                logger.warning(f"Invalid event source: {record.get('eventSource')}")
                # Continue in YOLO mode
            
            # Check if it's an ObjectCreated event - YOLO mode: make this check optional
            if not record.get('eventName', '').startswith('ObjectCreated:'):
                logger.warning(f"Event name doesn't start with ObjectCreated: {record.get('eventName')}")
                # Don't raise an error in YOLO mode
            
            # Check if the record has s3 data
            if 's3' not in record:
                logger.error("No s3 data in record")
                raise ValidationError("Invalid S3 event: No S3 data found")
            
            # Extract bucket and key
            bucket_name = record['s3']['bucket']['name']
            object_key = record['s3']['object']['key']
            
            logger.info(f"Extracted from S3 event: bucket={bucket_name}, key={object_key}")
            
            # Try URL decoding the key
            try:
                decoded_key = urllib.parse.unquote_plus(object_key)
                logger.info(f"Decoded key: {decoded_key}")
                if decoded_key != object_key:
                    object_key = decoded_key
            except Exception as e:
                logger.warning(f"Error decoding key: {str(e)}")
            
            return bucket_name, object_key
        
        # If we can't identify the event type, try to extract bucket and key from any structure
        else:
            logger.warning("Unknown event pattern - attempting to extract bucket and key")
            
            # Try to find bucket and key in the event structure
            if isinstance(event, dict):
                # Dump the event structure for debugging
                logger.info(f"Event keys at root level: {list(event.keys())}")
                
                # Try to find bucket and key in common patterns
                bucket_name = None
                object_key = None
                
                # Try direct access
                if 'bucket' in event and 'key' in event:
                    bucket_name = event['bucket']
                    object_key = event['key']
                    logger.info(f"Found bucket and key at root level")
                
                # Try nested in 'detail'
                elif 'detail' in event and isinstance(event['detail'], dict):
                    detail = event['detail']
                    logger.info(f"Detail keys: {list(detail.keys())}")
                    
                    if 'bucket' in detail and 'key' in detail:
                        bucket_name = detail['bucket']
                        object_key = detail['key']
                        logger.info(f"Found bucket and key in detail")
                    
                    elif 'bucket' in detail and isinstance(detail['bucket'], dict) and 'name' in detail['bucket']:
                        bucket_name = detail['bucket']['name']
                        if 'object' in detail and isinstance(detail['object'], dict) and 'key' in detail['object']:
                            object_key = detail['object']['key']
                            logger.info(f"Found bucket.name and object.key in detail")
                
                if bucket_name and object_key:
                    logger.info(f"Extracted from unknown pattern: bucket={bucket_name}, key={object_key}")
                    
                    # Try URL decoding the key
                    try:
                        decoded_key = urllib.parse.unquote_plus(object_key)
                        logger.info(f"Decoded key: {decoded_key}")
                        if decoded_key != object_key:
                            object_key = decoded_key
                    except Exception as e:
                        logger.warning(f"Error decoding key: {str(e)}")
                    
                    return bucket_name, object_key
            
            # If we couldn't extract bucket and key, raise an error
            logger.error("Could not extract bucket and key from event")
            raise ValidationError("Invalid event: Could not extract bucket and key")
    
    except KeyError as e:
        logger.error(f"KeyError in validate_s3_event: {str(e)}")
        raise ValidationError(f"Invalid event structure: {str(e)}")
    except Exception as e:
        logger.error(f"Unexpected error in validate_s3_event: {str(e)}")
        raise ValidationError(f"Error processing event: {str(e)}")

def validate_pdf_file(s3_client, bucket, key):
    """
    Validate that the file is a PDF and not too large.
    
    Args:
        s3_client: Boto3 S3 client
        bucket (str): S3 bucket name
        key (str): S3 object key
        
    Raises:
        ValidationError: If the file is not a PDF or too large
    """
    try:
        logger.info(f"Validating PDF file: bucket={bucket}, key={key}")
        
        # Get object metadata
        response = s3_client.head_object(Bucket=bucket, Key=key)
        logger.info(f"Head object response: {json.dumps(response, default=str)}")
        
        # Check content type - YOLO mode: make this check optional
        content_type = response.get('ContentType', '')
        logger.info(f"Content type: {content_type}")
        if 'application/pdf' not in content_type.lower():
            logger.warning(f"Content type is not application/pdf: {content_type}")
            # Don't raise an error in YOLO mode
        
        # Check file size (limit to 50MB) - YOLO mode: increase limit
        content_length = response.get('ContentLength', 0)
        max_size = 100 * 1024 * 1024  # 100MB in YOLO mode
        logger.info(f"File size: {content_length} bytes, max allowed: {max_size} bytes")
        if content_length > max_size:
            logger.warning(f"File too large: {content_length} bytes")
            # Don't raise an error in YOLO mode
        
    except Exception as e:
        logger.error(f"Error in validate_pdf_file: {str(e)}")
        if hasattr(e, 'response') and e.response.get('Error', {}).get('Code') == 'NoSuchKey':
            logger.error(f"File not found: {key}")
            # Don't raise an error in YOLO mode
            return
        logger.error(f"Other error validating PDF file: {str(e)}")
        # Don't raise an error in YOLO mode

def validate_analysis_result(result):
    """
    Validate the structure of the analysis result.
    
    Args:
        result (dict): Analysis result to validate
        
    Returns:
        bool: True if the result is valid
        
    Raises:
        ValidationError: If the result is invalid
    """
    required_keys = [
        'executive_summary', 'quality_rating', 'controls', 
        'framework_mappings', 'identified_gaps'
    ]
    
    # Check for required keys
    for key in required_keys:
        if key not in result:
            raise ValidationError(f"Missing required key: {key}")
    
    # Validate quality_rating is in range [0, 5]
    if not isinstance(result['quality_rating'], (int, float)):
        raise ValidationError("quality_rating must be a number")
    
    if not (0 <= result['quality_rating'] <= 5):
        raise ValidationError("quality_rating must be between 0 and 5")
    
    # Validate controls structure
    if not isinstance(result['controls'], list):
        raise ValidationError("controls must be a list")
    
    # Validate framework_mappings is a dictionary
    if not isinstance(result['framework_mappings'], dict):
        raise ValidationError("framework_mappings must be a dictionary")
    
    # Validate identified_gaps is a list
    if not isinstance(result['identified_gaps'], list):
        raise ValidationError("identified_gaps must be a list")
    
    return True

def validate_json_format(json_str):
    """
    Validate that a string is valid JSON.
    
    Args:
        json_str (str): JSON string to validate
        
    Returns:
        bool: True if the string is valid JSON, False otherwise
    """
    try:
        json.loads(json_str)
        return True
    except json.JSONDecodeError:
        return False 